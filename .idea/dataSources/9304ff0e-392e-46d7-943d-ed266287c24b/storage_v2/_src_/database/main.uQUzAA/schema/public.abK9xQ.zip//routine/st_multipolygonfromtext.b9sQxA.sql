create function st_multipolygonfromtext(text) returns geometry
    immutable
    strict
    parallel safe
    cost 250
    language sql
as
$$SELECT public.ST_MPolyFromText($1)$$;

alter function st_multipolygonfromtext(unknown) owner to db_user;

