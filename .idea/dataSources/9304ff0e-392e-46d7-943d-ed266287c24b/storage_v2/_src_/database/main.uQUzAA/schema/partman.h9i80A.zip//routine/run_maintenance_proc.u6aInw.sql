create procedure run_maintenance_proc(IN p_wait integer DEFAULT 0, IN p_analyze boolean DEFAULT false, IN p_jobmon boolean DEFAULT true)
    language plpgsql
as
$$
DECLARE

v_adv_lock              boolean;
v_parent_table          text;
v_sql                   text;

BEGIN

v_adv_lock := pg_catalog.pg_try_advisory_lock(hashtext('pg_partman run_maintenance_proc'));
IF v_adv_lock = false THEN
    RAISE NOTICE 'Advisory lock notice (pg_partman run_maintenance_proc): Partman maintenance procedure already running or another session has not released its advisory lock.';
    RETURN;
END IF;

IF pg_catalog.pg_is_in_recovery() THEN
    RAISE DEBUG 'pg_partmain maintenance procedure called on replica. Doing nothing.';
    RETURN;
END IF;

FOR v_parent_table IN
    SELECT parent_table
    FROM partman.part_config
    WHERE undo_in_progress = false
    AND automatic_maintenance = 'on'
    ORDER BY maintenance_order ASC NULLS LAST
LOOP
/*
 * Run maintenance with a commit between each partition set
 */
    v_sql := pg_catalog.format('SELECT %s.run_maintenance(%L, p_jobmon := %L',
        'partman', v_parent_table, p_jobmon);

    IF p_analyze IS NOT NULL THEN
        v_sql := v_sql || pg_catalog.format(', p_analyze := %L', p_analyze);
    END IF;

    v_sql := v_sql || ')';

    RAISE DEBUG 'v_sql run_maintenance_proc: %', v_sql;

    EXECUTE v_sql;
    COMMIT;

    PERFORM pg_catalog.pg_sleep(p_wait);

END LOOP;

PERFORM pg_catalog.pg_advisory_unlock(hashtext('pg_partman run_maintenance_proc'));
END
$$;

alter procedure run_maintenance_proc(integer, boolean, boolean) owner to db_user;

