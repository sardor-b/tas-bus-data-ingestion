create function check_epoch_type(p_type text) returns boolean
    immutable
    SET search_path = partman, pg_catalog, pg_temp
    language plpgsql
as
$$
DECLARE
v_result    boolean;
BEGIN
    SELECT p_type IN ('none', 'seconds', 'milliseconds', 'microseconds', 'nanoseconds') INTO v_result;
    RETURN v_result;
END
$$;

alter function check_epoch_type(text) owner to db_user;

