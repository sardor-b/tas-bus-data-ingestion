create function overlaps_nd(unknown, unknown) returns boolean
    immutable
    strict
    parallel safe
    language c
as
$$SELECT $2 OPERATOR(public.&&&) $1;$$;

alter function overlaps_nd(unknown, unknown) owner to db_user;

