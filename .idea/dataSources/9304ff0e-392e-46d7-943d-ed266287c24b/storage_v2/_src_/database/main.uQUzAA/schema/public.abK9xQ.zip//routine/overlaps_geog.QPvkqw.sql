create function overlaps_geog(unknown, unknown) returns boolean
    immutable
    strict
    language c
as
$$SELECT $2 OPERATOR(public.&&) $1;$$;

alter function overlaps_geog(unknown, unknown) owner to db_user;

