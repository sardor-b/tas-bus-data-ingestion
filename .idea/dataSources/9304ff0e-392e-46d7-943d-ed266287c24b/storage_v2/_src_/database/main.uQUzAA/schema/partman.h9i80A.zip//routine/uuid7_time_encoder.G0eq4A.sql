create function uuid7_time_encoder(ts timestamp with time zone) returns uuid
    SET search_path = partman, pg_catalog, pg_temp
    language plpgsql
as
$$
DECLARE
    ts_millis BIGINT;
    ts_hex TEXT;
BEGIN
    -- Convert the milliseconds to a 12 char hex with zero pad
    ts_millis := EXTRACT(EPOCH FROM ts) * 1000;
    ts_hex := lpad(to_hex(ts_millis), 12, '0');

    -- Split the timestamp into two parts as per spec
    RETURN substr(ts_hex, 1, 8) || '-' || substr(ts_hex, 9, 4) || '-0000-0000-000000000000';
END;
$$;

alter function uuid7_time_encoder(timestamp with time zone) owner to db_user;

