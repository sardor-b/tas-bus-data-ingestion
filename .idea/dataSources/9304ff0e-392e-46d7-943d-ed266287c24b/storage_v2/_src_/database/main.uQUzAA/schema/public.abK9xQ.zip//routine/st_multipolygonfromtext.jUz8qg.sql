create function st_multipolygonfromtext(text, integer) returns geometry
    immutable
    strict
    parallel safe
    cost 250
    language sql
as
$$SELECT public.ST_MPolyFromText($1, $2)$$;

alter function st_multipolygonfromtext(unknown, unknown) owner to db_user;

