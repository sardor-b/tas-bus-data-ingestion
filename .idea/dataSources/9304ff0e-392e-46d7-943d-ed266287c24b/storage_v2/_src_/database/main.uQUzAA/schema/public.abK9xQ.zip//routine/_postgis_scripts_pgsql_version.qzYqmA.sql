create function _postgis_scripts_pgsql_version() returns text
    immutable
    language sql
as
$$SELECT '180'::text AS version$$;

alter function _postgis_scripts_pgsql_version() owner to db_user;

