create function st_scale(unknown, unknown, origin unknown) returns geometry
    immutable
    strict
    parallel safe
    cost 50
    language c
as
$$SELECT public.ST_Scale($1, $2, $3, 1)$$;

alter function st_scale(unknown, unknown, unknown) owner to db_user;

