create function postgis_scripts_installed() returns text
    immutable
    language sql
as
$$ SELECT trim('3.6.2'::text || $rev$ 08d9b9f $rev$) AS version $$;

alter function postgis_scripts_installed() owner to db_user;

