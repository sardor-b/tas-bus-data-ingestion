create function overlaps_2d(geometry, box2df) returns boolean
    immutable
    strict
    parallel safe
    cost 1
    language sql
as
$$SELECT $2 OPERATOR(public.&&) $1;$$;

alter function overlaps_2d(unknown, unknown) owner to db_user;

