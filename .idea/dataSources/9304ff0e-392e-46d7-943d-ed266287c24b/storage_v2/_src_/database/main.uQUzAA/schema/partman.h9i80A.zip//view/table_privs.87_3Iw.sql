create view table_privs(grantor, grantee, table_schema, table_name, privilege_type) as
SELECT u_grantor.rolname AS grantor,
       grantee.rolname   AS grantee,
       nc.nspname        AS table_schema,
       c.relname         AS table_name,
       c.prtype          AS privilege_type
FROM (SELECT pg_class.oid,
             pg_class.relname,
             pg_class.relnamespace,
             pg_class.relkind,
             pg_class.relowner,
             (aclexplode(COALESCE(pg_class.relacl, acldefault('r'::"char", pg_class.relowner)))).grantor        AS grantor,
             (aclexplode(COALESCE(pg_class.relacl,
                                  acldefault('r'::"char", pg_class.relowner)))).grantee                         AS grantee,
             (aclexplode(COALESCE(pg_class.relacl,
                                  acldefault('r'::"char", pg_class.relowner)))).privilege_type                  AS privilege_type,
             (aclexplode(COALESCE(pg_class.relacl,
                                  acldefault('r'::"char", pg_class.relowner)))).is_grantable                    AS is_grantable
      FROM pg_class) c(oid, relname, relnamespace, relkind, relowner, grantor, grantee, prtype, grantable),
     pg_namespace nc,
     pg_roles u_grantor,
     (SELECT pg_roles.oid,
             pg_roles.rolname
      FROM pg_roles
      UNION ALL
      SELECT 0::oid AS oid,
             'PUBLIC'::name) grantee(oid, rolname)
WHERE c.relnamespace = nc.oid
  AND (c.relkind = ANY (ARRAY ['r'::"char", 'v'::"char", 'p'::"char"]))
  AND c.grantee = grantee.oid
  AND c.grantor = u_grantor.oid
  AND (c.prtype IN (SELECT (aclexplode(acldefault('r'::"char", c.relowner))).privilege_type AS privilege_type))
  AND (pg_has_role(u_grantor.oid, 'USAGE'::text) OR pg_has_role(grantee.oid, 'USAGE'::text) OR
       grantee.rolname = 'PUBLIC'::name);

alter table table_privs
    owner to db_user;

