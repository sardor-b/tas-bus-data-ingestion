create function st_transform(geom geometry, from_proj text, to_srid integer) returns geometry
    immutable
    strict
    parallel safe
    cost 5000
    language sql
as
$$SELECT public.postgis_transform_geometry($1, $2, proj4text, $3)
	FROM public.spatial_ref_sys WHERE srid=$3;$$;

alter function st_transform(geometry, text, integer) owner to db_user;

