create function check_automatic_maintenance_value(p_automatic_maintenance text) returns boolean
    immutable
    SET search_path = partman, pg_catalog, pg_temp
    language plpgsql
as
$$
DECLARE
v_result    boolean;
BEGIN
    SELECT p_automatic_maintenance IN ('on', 'off') INTO v_result;
    RETURN v_result;
END
$$;

alter function check_automatic_maintenance_value(text) owner to db_user;

