create function st_geomfromgeohash(text, integer DEFAULT NULL::integer) returns geometry
    immutable
    parallel safe
    cost 50
    language sql
as
$$ SELECT CAST(public.ST_Box2dFromGeoHash($1, $2) AS public.geometry); $$;

alter function st_geomfromgeohash(unknown, unknown) owner to db_user;

