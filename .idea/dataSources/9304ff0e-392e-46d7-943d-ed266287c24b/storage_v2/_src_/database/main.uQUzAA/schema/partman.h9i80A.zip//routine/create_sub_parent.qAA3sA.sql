create function create_sub_parent(p_top_parent text, p_control text, p_interval text, p_type text DEFAULT 'range'::text, p_default_table boolean DEFAULT true, p_declarative_check text DEFAULT NULL::text, p_constraint_cols text[] DEFAULT NULL::text[], p_premake integer DEFAULT 4, p_start_partition text DEFAULT NULL::text, p_epoch text DEFAULT 'none'::text, p_jobmon boolean DEFAULT true, p_date_trunc_interval text DEFAULT NULL::text, p_control_not_null boolean DEFAULT true, p_time_encoder text DEFAULT NULL::text, p_time_decoder text DEFAULT NULL::text) returns boolean
    SET search_path = partman, pg_catalog, pg_temp
    language plpgsql
as
$$
DECLARE

BEGIN
/*
    This is an alias function for create_sub_partition() for backward compatibility
*/

RETURN partman.create_sub_partition(
    p_top_parent
    , p_control
    , p_interval
    , p_type
    , p_default_table
    , p_declarative_check
    , p_constraint_cols
    , p_premake
    , p_start_partition
    , p_epoch
    , p_jobmon
    , p_date_trunc_interval
    , p_control_not_null
    , p_time_encoder
    , p_time_decoder
);

END
$$;

alter function create_sub_parent(text, text, text, text, boolean, text, text[], integer, text, text, boolean, text, boolean, text, text) owner to db_user;

