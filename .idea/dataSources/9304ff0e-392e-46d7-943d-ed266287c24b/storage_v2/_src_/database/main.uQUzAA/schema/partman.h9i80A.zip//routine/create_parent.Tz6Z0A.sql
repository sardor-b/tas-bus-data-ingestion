create function create_parent(p_parent_table text, p_control text, p_interval text, p_type text DEFAULT 'range'::text, p_epoch text DEFAULT 'none'::text, p_premake integer DEFAULT 4, p_start_partition text DEFAULT NULL::text, p_default_table boolean DEFAULT true, p_automatic_maintenance text DEFAULT 'on'::text, p_constraint_cols text[] DEFAULT NULL::text[], p_template_table text DEFAULT NULL::text, p_jobmon boolean DEFAULT true, p_date_trunc_interval text DEFAULT NULL::text, p_control_not_null boolean DEFAULT true, p_time_encoder text DEFAULT NULL::text, p_time_decoder text DEFAULT NULL::text, p_offset_id bigint DEFAULT 0) returns boolean
    SET search_path = partman, pg_catalog, pg_temp
    language plpgsql
as
$$
DECLARE

BEGIN
/*
    This is an alias function for create_partition() for backward compatibility
*/

RETURN partman.create_partition(
    p_parent_table
    , p_control
    , p_interval
    , p_type
    , p_epoch
    , p_premake
    , p_start_partition
    , p_default_table
    , p_automatic_maintenance
    , p_constraint_cols
    , p_template_table
    , p_jobmon
    , p_date_trunc_interval
    , p_control_not_null
    , p_time_encoder
    , p_time_decoder
    , p_offset_id
);

END
$$;

alter function create_parent(text, text, text, text, text, integer, text, boolean, text, text[], text, boolean, text, boolean, text, text, bigint) owner to db_user;

