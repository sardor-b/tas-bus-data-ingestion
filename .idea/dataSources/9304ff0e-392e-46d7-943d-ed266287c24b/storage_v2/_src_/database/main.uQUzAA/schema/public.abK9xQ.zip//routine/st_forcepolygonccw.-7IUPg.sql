create function st_forcepolygonccw(geometry) returns geometry
    immutable
    strict
    parallel safe
    cost 50
    language sql
as
$$ SELECT
	  CASE WHEN public.ST_GeometryType($1) IN ('ST_Polygon', 'ST_MultiPolygon')
	  THEN public.ST_Reverse(public.ST_ForcePolygonCW($1))
	  ELSE $1 END $$;

alter function st_forcepolygonccw(geometry) owner to db_user;

