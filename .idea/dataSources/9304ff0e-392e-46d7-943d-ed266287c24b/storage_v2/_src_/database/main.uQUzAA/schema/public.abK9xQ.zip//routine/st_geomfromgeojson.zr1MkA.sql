create function st_geomfromgeojson(unknown) returns geometry
    immutable
    strict
    parallel safe
    cost 250
    language c
as
$$SELECT public.ST_GeomFromGeoJson($1::text)$$;

alter function st_geomfromgeojson(unknown) owner to db_user;

