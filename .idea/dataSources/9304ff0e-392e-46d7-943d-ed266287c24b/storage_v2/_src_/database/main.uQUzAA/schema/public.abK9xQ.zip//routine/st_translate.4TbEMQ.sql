create function st_translate(geometry, double precision, double precision) returns geometry
    immutable
    strict
    parallel safe
    cost 50
    language sql
as
$$SELECT public.ST_Translate($1, $2, $3, 0)$$;

alter function st_translate(geometry, double precision, double precision) owner to db_user;

